using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManager : MonoBehaviour
{
    public TextMeshProUGUI[] dialogueTexts; // Array of TextMeshProUGUI components
    public GameObject dialogueBox; // Reference to the Canvas or Panel containing the dialogue box
    public Button confirmButton; // Reference to the Confirm Button
    private bool isDialogueActive = false; // Flag to check if dialogue is active
    private int currentDialogueIndex = 0; // Index to keep track of the current dialogue text
    private int nextDialogueIndex = 0; // Index to keep track of the next dialogue text
    public static bool freezeConfirm = false;
    public static int dialogueCounter = 0;


    public void Start()
    {
        // Set the static dialogueBox in DialogueManager
        EventManager.dialogueBox = dialogueBox;

         // Set the static freezeConfirm in EventManager
        EventManager.freezeConfirm = freezeConfirm;

        // Set the static dialogueCounter in EventManager
        EventManager.dialogueCounter = dialogueCounter;

        //confirmButton.onClick.AddListener(ShowNextDialogue);
    }

    public void Update()
    {
        if (dialogueCounter % 2 == 1)  { // If Odd
            ShowNextDialogue();
            dialogueCounter++;
        }

        if (!freezeConfirm) {
            confirmButton.onClick.AddListener(ShowNextDialogue);
        }

        if (MovementManager.experienceEnded) {
            CloseDialogue();
            MovementManager.experienceEnded = false;
        }
    }

    // Function to show the dialogue
    public void ShowDialogue(TextMeshProUGUI[] texts)
    {
        // Reset index
        currentDialogueIndex = 0;

        // Get Next index
        nextDialogueIndex = currentDialogueIndex;
        nextDialogueIndex++;

        // Make the current TextMeshProUGUI object transparent
        Color currentColor = dialogueTexts[currentDialogueIndex].color;
        currentColor.a = 0f; // Set alpha to 0 (transparent)
        
        for (int i = 1; i < dialogueTexts.Length; i++) {
            dialogueTexts[i].color = currentColor;
        }

        // Set dialogue box active
        dialogueBox.SetActive(true);

        // Start coroutine to display text letter by letter
        StartCoroutine(DisplayText(texts[currentDialogueIndex]));
    
        //Debug.Log("Showing dialogue for index: " + currentDialogueIndex);
    }


    // Coroutine to display text letter by letter
    IEnumerator DisplayText(TextMeshProUGUI text)
    {
        isDialogueActive = true;

        string fullText = text.text;
        text.text = ""; // Clear the dialogue text

        //Debug.Log("Full Text: " + fullText); // Debug statement to check the full text

        foreach (char letter in fullText)
        {
            text.text += letter; // Add a letter to the dialogue text
            //Debug.Log("Displaying letter: " + letter); // Debug statement for each letter
            yield return new WaitForSeconds(0.05f); // Wait for a short time before the next letter
        }

        isDialogueActive = false;
    }


    // Function to show the next dialogue
    public void ShowNextDialogue()
    {
        if (!isDialogueActive && currentDialogueIndex < dialogueTexts.Length - 1)
        {
            StartCoroutine(TransitionToNextDialogue());
        }
        else if (!isDialogueActive && currentDialogueIndex == dialogueTexts.Length - 1)
        {
            CloseDialogue();
        }
    }

    IEnumerator TransitionToNextDialogue()
{
    isDialogueActive = true;

    // Make the current TextMeshProUGUI object transparent
    Color currentColor = dialogueTexts[currentDialogueIndex].color;
    currentColor.a = 0f; // Set alpha to 0 (transparent)
    dialogueTexts[currentDialogueIndex].color = currentColor;

    // Reset the text of the current TextMeshProUGUI object
    dialogueTexts[currentDialogueIndex].text = "";

    // Check if there's a next dialogue text
    if (nextDialogueIndex < dialogueTexts.Length)
    {
        // Make the next TextMeshProUGUI object visible
        Color nextColor = dialogueTexts[nextDialogueIndex].color;
        nextColor.a = 1f; // Set alpha to 1 (visible)
        dialogueTexts[nextDialogueIndex].color = nextColor;

        // Start displaying the text of the next TextMeshProUGUI object
        yield return StartCoroutine(DisplayText(dialogueTexts[nextDialogueIndex]));

        // Increment the next dialogue index
        nextDialogueIndex++;
    }

    // Increment the current dialogue index
    currentDialogueIndex++;

    isDialogueActive = false;
}






    // Function to close the dialogue
    public void CloseDialogue()
    {
        // Hide the dialogue box
        dialogueBox.SetActive(false);
    }
}
