using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using Unity.VisualScripting.Dependencies.NCalc;
using UnityEngine;

public class MoveObject : MonoBehaviour
{
public void moveObject() {
    this.transform.position = new Vector3(-3,3,-4);
}
}
