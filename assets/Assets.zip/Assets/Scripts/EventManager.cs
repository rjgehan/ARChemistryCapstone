
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class EventManager : MonoBehaviour
{
    public int electronsForEvent; // Number of electrons needed to trigger an event
    public static GameObject dialogueBox;
    public static bool moreEvents;
    public static bool freezeConfirm;
    public static int dialogueCounter;

    public Transform[] elements; // Array of element transforms
    public Transform[] electrons; // Array of electron transforms
    public Transform[] bonds; // Array of bond transforms
    public Vector3[] elementTargetPositions; // Array of target positions for elements
    public Vector3[] electronTargetPositions; // Array of target positions for electrons
    public Vector3[] bondTargetPositions; // Array of target positions for electrons

    // Arrays for storing initial positions of elements, electrons, and bonds
    private Vector3[] initialElementPositions;
    private Vector3[] initialElectronPositions;
    private Vector3[] initialBondPositions;

    void Update()
    {
        // Check if the required number of electrons are clicked
        if (ElectronController.totalClickables == electronsForEvent)
        {
            // Trigger the event
            TriggerEvent();
        }
    }

    void TriggerEvent()
    {
        // Call the method to start the event
        StartEvent();

        // Reset the totalClickables
        ElectronController.totalClickables = 0;

        // Trigger movement in MovementManager
        MoveElementsAndElectrons();

        // Trigger reset movement
        //ResetElementsAndElectronsPositions();
    }

    void StartEvent()
    {
        // Logic to start the event
        Debug.Log("Event triggered!");

        // Move Dialogue Initially
        dialogueCounter++;

        
    }

    void NextDialogue() {
        dialogueCounter++;
    }

    // Example method to detect elements touching
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Element")) // Have a tag named "Element" for your elements
        {
            // Call the method to make elements touch
            MakeElementsTouchEvent();
        }
    }

    void MakeElementsTouchEvent()
    {
        // Logic to handle element touch
        Debug.Log("Elements touched!");

        // Trigger movement in MovementManager to move elements to a new position
        MoveElementsAndElectrons();

        // Wait for some time or detect when elements have moved to the new position
        StartCoroutine(WaitForMovement());
    }

    IEnumerator WaitForMovement()
    {
        // Wait for some time or detect when elements have moved to the new position
        yield return new WaitForSeconds(2.0f); // Wait for 2 seconds

        // Trigger movement in MovementManager to move elements back to their original positions
        ResetElementsAndElectronsPositions();
    }

        public void MoveElementsAndElectrons()
    {
        
        MoveObjects(elements, elementTargetPositions);
        MoveObjects(electrons, electronTargetPositions);
        MoveObjects(bonds, bondTargetPositions);
    }

    void MoveObjects(Transform[] objects, Vector3[] targetPositions)
    {
        for (int i = 0; i < objects.Length; i++)
        {
            if (i < targetPositions.Length)
            {
                // Example: Smoothly move towards the target position
                StartCoroutine(MoveCoroutine(objects[i], targetPositions[i], 1f)); // You can adjust the speed as needed
            }
            else
            {
                Debug.LogWarning("No target position defined for object at index " + i);
            }
        }
    }

    IEnumerator MoveCoroutine(Transform objectToMove, Vector3 targetPosition, float duration) 
    {
        Vector3 startPosition = objectToMove.position;
        float time = 0f;
        while (time < duration)
        {
            objectToMove.position = Vector3.Lerp(startPosition, targetPosition, time / duration);
            time += Time.deltaTime;
            yield return null;
        }
        objectToMove.position = targetPosition;
    }

     // Function to reset elements and electrons to their initial positions
    public void ResetElementsAndElectronsPositions()
    {
        ResetObjects(elements, initialElementPositions);
        ResetObjects(electrons, initialElectronPositions);
        ResetObjects(bonds, initialBondPositions);

        // Set isClickable to false
        ElectronController.isClickable = false;

        // Reset the color of all electrons to their original color
        foreach (Transform electron in electrons)
        {
            ElectronController electronController = electron.GetComponent<ElectronController>();
            if (electronController != null)
            {
                electronController.ChangeOriginalColor();
            }
        }

        foreach (Transform bond in bonds)
        {
            ElectronController electronController = bond.GetComponent<ElectronController>();
            if (electronController != null)
            {
                electronController.ChangeOriginalColor();
            }
        }
    }


    // Function to reset objects to their initial positions
    void ResetObjects(Transform[] objects, Vector3[] initialPositions)
    {
        for (int i = 0; i < objects.Length; i++)
        {
            objects[i].position = initialPositions[i];
        }
    }

    
}
