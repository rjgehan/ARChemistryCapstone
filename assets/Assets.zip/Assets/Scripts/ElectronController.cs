using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ElectronController : MonoBehaviour
{
    public Vector3 targetPosition; // Set this in the inspector to define where the electron should move
    public Color clickedColor = Color.red; // Define the color when the electron is clicked

    private bool isMoving = false;
    private Color originalColor; // Store the original color of the electron
    public static int totalClickables = 0; // Counter to track clicked electrons
    public static int totalElectronCount; // Total number of electrons in the scene
    public static bool isClickable = false;

    public float scaleChangeAmount = 0.2f; // Amount to change the scale by
    public float maxScale = 0.9f; // Maximum scale value
    public float minScale = 0.5f; // Minimum scale value
    public bool clickLock;
    public static GameObject[] elementsToGrow;
    public static GameObject[] elementsToShrink;
     private static List<ElectronController> clickedElectrons = new List<ElectronController>();

public AudioSource audioSource;
public AudioClip selectClip; // Reference to your MP3 audio file

    private void Start()
    {
        
        // Store the original color of the electron
        originalColor = GetComponent<Renderer>().material.color;

        // Reset the color of the electron to its original color
        ChangeOriginalColor();
    }


    public void allowClicks() {
        isClickable = true;
    }

    private void OnMouseDown()
    {
        if (!clickLock) {
            if (isClickable) {
                if (!isMoving)
                {
                    if (!clickedElectrons.Contains(this))
                    {
                        MoveToTarget();
                        ChangeColor(clickedColor); // Change color when clicked
                        totalClickables++; // Increment clicked electron count
                        Debug.Log("Clicked.");

                        audioSource.clip = selectClip;
                        audioSource.Play();

                        clickedElectrons.Add(this); // Add the clicked electron to the list

                        // Check if all electrons have been clicked
                        if (totalClickables == totalElectronCount)
                        {
                            // Trigger movement of elements and electrons
                            MoveElementsAndElectrons();

                            // Trigger element scale changes if any
                            GrowOrShrink();
                        }
                    }
                }
            }
        }
    }

    private void MoveToTarget()
    {
        isMoving = true;
        // Example: Smoothly move towards the target position
        StartCoroutine(MoveCoroutine(targetPosition, 1f)); // You can adjust the speed as needed
    }

    IEnumerator MoveCoroutine(Vector3 target, float duration)
    {
        Vector3 startPosition = transform.position;
        float time = 0f;
        while (time < duration)
        {
            transform.position = Vector3.Lerp(startPosition, target, time / duration);
            time += Time.deltaTime;
            yield return null;
        }
        transform.position = target;
        isMoving = false;

        // Movement ended, can click again
        isClickable = true;
    }

    private void ChangeColor(Color newColor)
    {
        // Change the color of the electron
        GetComponent<Renderer>().material.color = newColor;
    }

    public void ChangeOriginalColor()
    {
        // Change the color of the electron
        GetComponent<Renderer>().material.color = originalColor;
    }

    public static void MoveElementsAndElectrons()
    {
        // Trigger movement of elements and electrons here
        Debug.Log("All electrons clicked, moving elements and electrons...");

        MovementManager movementManager = FindObjectOfType<MovementManager>();
        if (movementManager != null) {
            movementManager.MoveElementsAndElectrons();
        }
    }

    void GrowOrShrink()
    {
        scaleChangeAmount = 0.3f; 
        // Iterate over elements and grow them
        foreach (GameObject element in elementsToGrow)
        {
            IncreaseScale(element.transform);
        }
    
        // Iterate over elements and shrink them
        foreach (GameObject element in elementsToShrink)
        {
            DecreaseScale(element.transform);
        }       
    }


    public void IncreaseScale(Transform objToScale)
    {
        Vector3 newScale = objToScale.localScale + new Vector3(scaleChangeAmount, scaleChangeAmount, scaleChangeAmount);
        objToScale.localScale = Vector3.Min(newScale, new Vector3(maxScale, maxScale, maxScale));
    }

    public void DecreaseScale(Transform objToScale)
    {
        Vector3 newScale = objToScale.localScale - new Vector3(scaleChangeAmount, scaleChangeAmount, scaleChangeAmount);
        objToScale.localScale = Vector3.Max(newScale, new Vector3(minScale, minScale, minScale));
    }
}



