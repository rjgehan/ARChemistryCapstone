using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ElectronController : MonoBehaviour
{
    public Vector3 targetPosition; // Set this in the inspector to define where the electron should move
    public Color clickedColor = Color.red; // Define the color when the electron is clicked

    private bool isMoving = false;
    private Color originalColor; // Store the original color of the electron
    private static int clickedElectronCount = 0; // Counter to track clicked electrons
    private static int totalElectronCount = 14; // Total number of electrons in the scene
    public static bool isClickable = false;

public AudioSource audioSource;
public AudioClip selectClip; // Reference to your MP3 audio file

    private void Start()
    {
        // Store the original color of the electron
        originalColor = GetComponent<Renderer>().material.color;

        // Increment total electron count when an electron is instantiated
        //totalElectronCount++;
    }

    public void allowClicks() {
        isClickable = true;
    }

    private void OnMouseDown()
    {
        if (isClickable) {
            if (!isMoving)
            {
                MoveToTarget();
                ChangeColor(clickedColor); // Change color when clicked
                clickedElectronCount++; // Increment clicked electron count
                Debug.Log("Clicked.");

                audioSource.clip = selectClip;
                audioSource.Play();

                // Check if all electrons have been clicked
                if (clickedElectronCount == totalElectronCount)
                {
                    // Trigger movement of elements and electrons
                    MoveElementsAndElectrons();
                }
            }
        }
    }

    private void MoveToTarget()
    {
        isMoving = true;
        // Example: Smoothly move towards the target position
        StartCoroutine(MoveCoroutine(targetPosition, 1f)); // You can adjust the speed as needed
    }

    IEnumerator MoveCoroutine(Vector3 target, float duration)
    {
        Vector3 startPosition = transform.position;
        float time = 0f;
        while (time < duration)
        {
            transform.position = Vector3.Lerp(startPosition, target, time / duration);
            time += Time.deltaTime;
            yield return null;
        }
        transform.position = target;
        isMoving = false;
    }

    private void ChangeColor(Color newColor)
    {
        // Change the color of the electron
        GetComponent<Renderer>().material.color = newColor;
    }

    private static void MoveElementsAndElectrons()
    {
        // Trigger movement of elements and electrons here
        Debug.Log("All electrons clicked, moving elements and electrons...");

        MovementManager movementManager = FindObjectOfType<MovementManager>();
        if (movementManager != null) {
            movementManager.MoveElementsAndElectrons();
        }
    }
}


