using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementManager : MonoBehaviour
{
    public Transform[] elements; // Array of element transforms
    public Transform[] electrons; // Array of electron transforms
    public Transform[] bonds; // Array of bond transforms
    public Vector3[] elementTargetPositions; // Array of target positions for elements
    public Vector3[] electronTargetPositions; // Array of target positions for electrons
    public Vector3[] bondTargetPositions; // Array of target positions for electrons

public AudioSource audioSource;
public AudioClip successClip; // Reference to your MP3 audio file
    void Start()
    {
       // Get the AudioSource component attached to this GameObject
       /* audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            // If AudioSource component is not found, add it
            audioSource = gameObject.AddComponent<AudioSource>();
        }

        // Assign the success audio clip
        successClip = Resources.Load<AudioClip>("Audio/success");
        if (successClip == null)
        {
            Debug.LogError("Failed to load success audio clip!");
        }*/
    }
    void Update()
    {
        // This is just for demonstration purposes
        if (Input.GetKeyDown(KeyCode.Space))
        {
            MoveElementsAndElectrons();
        }
    }

    void InitializeTargetPositions()
    {
        // Initialize target positions for elements and electrons
        elementTargetPositions = new Vector3[]
        {
            new Vector3(1f, 0f, 1f),
            new Vector3(-1f, 0f, -1f),
            // Add more positions as needed
        };

        electronTargetPositions = new Vector3[]
        {
            new Vector3(2f, 0f, 2f),
            new Vector3(-2f, 0f, -2f),
            // Add more positions as needed
        };
    }

    public void MoveElementsAndElectrons()
    {

        MoveObjects(elements, elementTargetPositions);
        MoveObjects(electrons, electronTargetPositions);
        MoveObjects(bonds, bondTargetPositions);

        audioSource.clip = successClip;
        audioSource.Play();
    }

    void MoveObjects(Transform[] objects, Vector3[] targetPositions)
    {
        for (int i = 0; i < objects.Length; i++)
        {
            if (i < targetPositions.Length)
            {
                // Example: Smoothly move towards the target position
                StartCoroutine(MoveCoroutine(objects[i], targetPositions[i], 1f)); // You can adjust the speed as needed
            }
            else
            {
                Debug.LogWarning("No target position defined for object at index " + i);
            }
        }
    }

    IEnumerator MoveCoroutine(Transform objectToMove, Vector3 targetPosition, float duration)
    {
        Vector3 startPosition = objectToMove.position;
        float time = 0f;
        while (time < duration)
        {
            objectToMove.position = Vector3.Lerp(startPosition, targetPosition, time / duration);
            time += Time.deltaTime;
            yield return null;
        }
        objectToMove.position = targetPosition;
    }
}

