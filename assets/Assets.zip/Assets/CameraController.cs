using UnityEngine;

public class CameraController : MonoBehaviour
{
    public Transform targetObject; // Object to focus on
    public float circleRadius = 9f; // Radius of the circle around the object
    public float verticalRadius = 5f; // Radius of the vertical circle around the object
    public float rotateSpeed = 500f; // Speed of rotation
    public float zoomSpeed = 1f; // Speed of zooming
    public float minZoomDistance = 1f; // Minimum zoom distance
    public float maxZoomDistance = 10f; // Maximum zoom distance
    public float mouseSensitivity = 5f; // Mouse sensitivity multiplier

    private float horizontalAngle = 0f; // Horizontal angle around the object
    private float verticalAngle = 0f; // Vertical angle around the object
    private float distanceFromTarget = 5f; // Initial distance from the target object
    private bool hasStarted = false; // Flag to indicate if the game has started
    private Vector3 initialPosition; // Initial position of the camera

    void Start()
    {
        // Store the initial position of the camera
        initialPosition = transform.position;
        //StartCamera();
    }

    void Update()
    {
        if (!hasStarted)
            return;

        // Set values
        //circleRadius = 9f;
        //verticalRadius = 5f;
        //minZoomDistance = 1f;
        //maxZoomDistance = 10f;
        //distanceFromTarget = 0.7f;
        rotateSpeed = 500f;
        mouseSensitivity = 0.07f;

        // Calculate the position of the camera along the circle
        float x = Mathf.Sin(horizontalAngle) * circleRadius;
        float z = Mathf.Cos(horizontalAngle) * circleRadius;
        float y = Mathf.Sin(verticalAngle) * verticalRadius;

        Vector3 newPosition = targetObject.position + new Vector3(x, y, z) - transform.forward * distanceFromTarget;

        // Set the camera's new position
        transform.position = newPosition;

        // Calculate the direction from the camera to the object
        Vector3 lookDirection = targetObject.position - transform.position;

        // Calculate the rotation to directly face the object
        Quaternion targetRotation = Quaternion.LookRotation(lookDirection);

        // Smoothly rotate the camera to face the object
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotateSpeed * Time.deltaTime);

        // Handle mouse input for zooming
        float scrollInput = Input.GetAxis("Mouse ScrollWheel");
        if (scrollInput != 0f)
        {
            // Adjust the distance from the target based on the scroll input
            distanceFromTarget = Mathf.Clamp(distanceFromTarget - scrollInput * zoomSpeed, minZoomDistance, maxZoomDistance);
        }

        // Handle mouse input for camera rotation
        if (Input.GetMouseButton(0))
        {
            float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity; // Apply sensitivity multiplier
            float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity; // Apply sensitivity multiplier
            
            horizontalAngle += mouseX * rotateSpeed * Time.deltaTime;
            verticalAngle -= mouseY * rotateSpeed * Time.deltaTime;

            verticalAngle = Mathf.Clamp(verticalAngle, -Mathf.PI / 2f, Mathf.PI / 2f); // Limit vertical angle within [-pi/2, pi/2] range
        }

        // Keep the horizontal target angle within the range [0, 2*PI)
        horizontalAngle = Mathf.Repeat(horizontalAngle, 2 * Mathf.PI);
    }

    // Method to start the camera movement
    public void StartCamera()
    {
        // Set the camera's position to the initial position
        transform.position = initialPosition;
        hasStarted = true;

        // Call allowClicks() method of ElectronController
        ElectronController electronController = FindObjectOfType<ElectronController>();
        if (electronController != null)
        {
            electronController.allowClicks();
        }
    }
}
